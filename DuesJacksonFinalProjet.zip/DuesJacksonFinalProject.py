# Program Name: Inches to Meters Conversion
# Author: Jackson Dues
# Date: 4/21/2022
# Summary: convert a measurement in inches entered by user into meters
# Variables:
#   inches: measurement in inches entered by the user (int)
#   meters: measurement in meters (float)

import InchestoMetersConversion
